import 'package:flutter/material.dart';

class PlusScreen extends StatefulWidget {
  const PlusScreen({super.key, required AnimationController animationController});

  @override
  State<PlusScreen> createState() => _PlusScreenState();
}

class _PlusScreenState extends State<PlusScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [Text("data")],
      ),
    );
  }
}
