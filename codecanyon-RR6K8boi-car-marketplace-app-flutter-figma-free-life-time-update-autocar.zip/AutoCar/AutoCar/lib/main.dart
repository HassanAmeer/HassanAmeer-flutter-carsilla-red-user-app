// ignore_for_file: deprecated_member_use, non_constant_identifier_names, prefer_const_constructors, constant_identifier_names, unused_import

import 'package:autocar/transaction/9.10_transaction_bank_transfer.dart';
import 'package:autocar/transaction/9.11_transaction5.dart';
import 'package:autocar/transaction/9.1_transaction.dart';
import 'package:autocar/transaction/9.2_transaction2.dart';
import 'package:autocar/transaction/9.3_transaction3.dart';
import 'package:autocar/transaction/9.4_transaction4.dart';
import 'package:autocar/transaction/9.5_transaction_proccess.dart';
import 'package:autocar/transaction/9.6_transaction_accepted.dart';
import 'package:autocar/transaction/9.7_payment_detail.dart';
import 'package:autocar/transaction/9.8_payment_method.dart';
import 'package:autocar/transaction/9.9_transaction_credit_card.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Explore/6.4_stories_camera.dart';
import 'package:autocar/Message/8.3_chat_conversation.dart';
import 'package:autocar/Profile/7.3_profile_sell.dart';
import 'package:autocar/Profile/7.4_profile_setting.dart';
import 'package:autocar/Profile/7.5_profile_notification.dart';
import 'package:autocar/Profile/7.6_profile_transaction_history.dart';
import 'package:autocar/Profile/7.7_profile_account_preference.dart';
import 'package:autocar/Profile/7.8_profile_about_us.dart';
import 'package:autocar/Splash/onboarding.dart';
import 'package:autocar/Splash/spash_screen.dart';
import 'package:autocar/Widget/pageview.dart';
import 'package:autocar/auth/4.2_reset_password.dart';
import 'package:autocar/auth/4.3_reset_link_send.dart';
import 'package:autocar/auth/4.5_verification_code.dart';
import 'package:autocar/auth/4.6_new_password.dart';
import 'package:autocar/auth/4.7_reset_success.dart';
import 'package:autocar/auth/login_success.dart';
import 'package:autocar/auth/reset_email.dart';
import 'package:autocar/auth/sign_In.dart';
import 'package:autocar/auth/signup.dart';
import 'package:autocar/auth/signup_success.dart';
import 'package:autocar/selling/10.2_selling_step_2.dart';
import 'package:autocar/selling/10.3_selling_step_3.dart';
import 'package:autocar/selling/10.4_selling_step_4.dart';
import 'package:autocar/selling/10.5_selling_step_5.dart';
import 'package:autocar/selling/10.6_selling_success_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';

import 'selling/10.1_selling_step_1.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]).then(
    (_) => runApp(const MyApp()),
  );
}

class MyApp extends StatefulWidget {
  static setCustomeTheme(BuildContext context, int index) {
    final _MyAppState? state = context.findAncestorStateOfType<_MyAppState>();
    state!.setCustomeTheme(index);
  }

  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  setCustomeTheme(int index) {
    if (index == 6) {
      setState(() {
        AppTheme.isLightTheme = true;
      });
    } else if (index == 7) {
      setState(() {
        AppTheme.isLightTheme = false;
      });
    } else {}
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(milliseconds: 1)).then(
      (value) => SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness:
              AppTheme.isLightTheme ? Brightness.dark : Brightness.light,
          statusBarBrightness:
              AppTheme.isLightTheme ? Brightness.light : Brightness.dark,
          systemNavigationBarColor: Colors.black,
          systemNavigationBarDividerColor: Colors.grey,
          systemNavigationBarIconBrightness:
              AppTheme.isLightTheme ? Brightness.dark : Brightness.light,
        ),
      ),
    );
    return GetMaterialApp(
      scrollBehavior: const ScrollBehavior(
          // androidOverscrollIndicator: AndroidOverscrollIndicator.stretch
          ),
      title: "AutoCar",
      navigatorKey: NavKey.navKey,
      theme: AppTheme.getTheme(),
      debugShowCheckedModeBanner: false,
      routes: routes,
    );
  }

  var routes = <String, WidgetBuilder>{
    Routes.SPLASH: (BuildContext context) => SplashScreen(),
    Routes.INTRODUCTION: (BuildContext context) => OnBoardingScreen(),
    Routes.HOME: (BuildContext context) => PageScreen(),
  };
}

class Routes {
  static String SPLASH = "/";
  static const String INTRODUCTION = "/Splash/onboarding";
  static const String HOME = "/home/HomeScreen1";
}

class NavKey {
  static final navKey = GlobalKey<NavigatorState>();
}
