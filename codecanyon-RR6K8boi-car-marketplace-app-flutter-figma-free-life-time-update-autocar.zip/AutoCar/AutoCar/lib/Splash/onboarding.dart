// ignore_for_file: prefer_const_constructors, deprecated_member_use

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/auth/sign_In.dart';
import 'package:flutter/material.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({Key? key}) : super(key: key);

  @override
  State<OnBoardingScreen> createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  int pageNumber = 0;

  final PageController _pageController = PageController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        onPageChanged: (value) {},
        children: [
          onBoardin1(),
          onBoardin2(),
          onBoardin3(),
        ],
      ),
    );
  }

  Widget onBoardin1() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 50, right: 30),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                "Skip",
                style: Theme.of(context)
                    .textTheme
                    .displayLarge!
                    .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
              )
            ],
          ),
        ),
        Expanded(child: SizedBox()),
        Image.asset(
          AppTheme.isLightTheme ? ConstanceData.ob1 : ConstanceData.dob1,
          fit: BoxFit.contain,
        ),
        SizedBox(
          height: 45,
        ),
        Text(
          "Find Your Dream Car",
          style: Theme.of(context)
              .textTheme
              .displayLarge!
              .copyWith(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          "Find the car of your dreams from the \nworld's largest car market",
          textAlign: TextAlign.center,
          style: Theme.of(context)
              .textTheme
              .displayLarge!
              .copyWith(fontSize: 12, color: Theme.of(context).disabledColor),
        ),
        SizedBox(
          height: 60,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 4,
              width: 30,
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ),
            ),
            SizedBox(
              width: 10,
            ),
            Container(
              height: 4,
              width: 30,
              decoration: BoxDecoration(
                color: Theme.of(context).dividerColor,
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ),
            ),
          ],
        ),
        SizedBox(
          height: 40,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16, right: 16, bottom: 40),
          child: MyButton(
              btnName: "Get Started",
              click: () {
                setState(() {
                  _pageController.jumpToPage(1);
                });
              }),
        )
      ],
    );
  }

  Widget onBoardin2() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 50, right: 30),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                "Skip",
                style: Theme.of(context)
                    .textTheme
                    .displayLarge!
                    .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
              )
            ],
          ),
        ),
        Expanded(child: SizedBox()),
        Image.asset(
          AppTheme.isLightTheme ? ConstanceData.ob2 : ConstanceData.dob2,
          height: 250,
        ),
        SizedBox(
          height: 60,
        ),
        Text(
          "Sell Your Car",
          style: Theme.of(context)
              .textTheme
              .displayLarge!
              .copyWith(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          "Post your ad to interested buyers \naround the world",
          textAlign: TextAlign.center,
          style: Theme.of(context)
              .textTheme
              .displayLarge!
              .copyWith(fontSize: 12, color: Theme.of(context).disabledColor),
        ),
        SizedBox(
          height: 60,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 4,
              width: 30,
              decoration: BoxDecoration(
                color: Theme.of(context).disabledColor,
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ),
            ),
            SizedBox(
              width: 10,
            ),
            Container(
              height: 4,
              width: 30,
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ),
            ),
          ],
        ),
        SizedBox(
          height: 40,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16, right: 16, bottom: 40),
          child: MyButton(
              btnName: "Get Started",
              click: () {
                setState(() {
                  _pageController.jumpToPage(2);
                });
              }),
        )
      ],
    );
  }

  Widget onBoardin3() {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Image.asset(
              ConstanceData.ob4,
              fit: BoxFit.contain,
              width: MediaQuery.of(context).size.width,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Image.asset(
                AppTheme.isLightTheme ? ConstanceData.ob3 : ConstanceData.dob3,
                fit: BoxFit.contain,
                width: MediaQuery.of(context).size.width,
              ),
            ),
          ],
        ),
        Expanded(
          child: ListView(
            padding: EdgeInsets.only(
                left: 16,
                right: 16,
                top: MediaQuery.of(context).padding.top + 16,
                bottom: MediaQuery.of(context).padding.bottom),
            children: [
              Text(
                "Let’s Get Started",
                textAlign: TextAlign.center,
                style: Theme.of(context)
                    .textTheme
                    .displayLarge!
                    .copyWith(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Sign up or log in to find out the\nbest car for you",
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.displayLarge!.copyWith(
                    fontSize: 12, color: Theme.of(context).disabledColor),
              ),
              SizedBox(
                height: 40,
              ),
              MyButton(
                  btnName: "Continue with Email",
                  click: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => SignInScreen(),
                      ),
                    );
                  }),
              SizedBox(
                height: 20,
              ),
              Container(
                height: 50,
                width: double.infinity,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Theme.of(context).dividerColor,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      ConstanceData.ob5,
                      height: 25,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Continue with Google",
                      style: Theme.of(context)
                          .textTheme
                          .displayLarge!
                          .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                height: 50,
                width: double.infinity,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Theme.of(context).dividerColor,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      AppTheme.isLightTheme
                          ? ConstanceData.ob6
                          : ConstanceData.dob6,
                      height: 25,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Continue with Apple",
                      style: Theme.of(context)
                          .textTheme
                          .displayLarge!
                          .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 50,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Don’t have an account?",
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 12, color: Theme.of(context).disabledColor),
                  ),
                  Text(
                    " Sign Up",
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: Theme.of(context).primaryColor),
                  ),
                ],
              )
            ],
          ),
        ),
      ],
    );
  }
}
