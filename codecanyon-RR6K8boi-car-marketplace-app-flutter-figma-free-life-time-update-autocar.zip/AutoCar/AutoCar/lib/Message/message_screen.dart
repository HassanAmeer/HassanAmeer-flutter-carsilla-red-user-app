// // ignore_for_file: prefer_const_constructors

// ignore_for_file: annotate_overrides, prefer_const_constructors, unnecessary_new

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Message/8.3_chat_conversation.dart';
import 'package:autocar/Widget/textFiealds.dart';
import 'package:flutter/material.dart';

class MessageScreen extends StatefulWidget {
  final AnimationController animationController;

  const MessageScreen({super.key, required this.animationController});

  @override
  State<MessageScreen> createState() => _MessageScreenState();
}

class _MessageScreenState extends State<MessageScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late ScrollController controller;
  bool isLoadingSliderDetail = false;
  var sliderImageHieght = 0.0;
  void initState() {
    _animationController =
        AnimationController(duration: Duration(milliseconds: 0), vsync: this);
    widget.animationController.forward();
    controller = ScrollController(initialScrollOffset: 0.0);

    controller.addListener(() {
      // ignore: unnecessary_null_comparison
      if (context != null) {
        if (controller.offset < 0) {
          _animationController.animateTo(0.0);
        } else if (controller.offset > 0.0 &&
            controller.offset < sliderImageHieght) {
          if (controller.offset < ((sliderImageHieght / 1.5))) {
            _animationController
                .animateTo((controller.offset / sliderImageHieght));
          } else {
            _animationController
                .animateTo((sliderImageHieght / 1.5) / sliderImageHieght);
          }
        }
      }
    });
    loadingSliderDetail();
    super.initState();
  }

  loadingSliderDetail() async {
    setState(() {
      isLoadingSliderDetail = true;
    });
    await Future.delayed(const Duration(milliseconds: 700));
    setState(() {
      isLoadingSliderDetail = false;
    });
  }

  bool isdark = false;
  int index = 0;
  @override
  Widget build(BuildContext context) {
    sliderImageHieght = MediaQuery.of(context).size.width * 1.3;
    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget? child) {
        return FadeTransition(
            opacity: widget.animationController,
            child: Transform(
                transform: new Matrix4.translationValues(
                  0.0,
                  40 * (1.0 - widget.animationController.value),
                  0.0,
                ),
                child: Scaffold(
                  body: Padding(
                    padding: EdgeInsets.only(
                        left: 16,
                        right: 16,
                        top: MediaQuery.of(context).padding.top + 16,
                        bottom: MediaQuery.of(context).padding.bottom + 16),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Message",
                              style: Theme.of(context)
                                  .textTheme
                                  .displayLarge!
                                  .copyWith(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        MyTextFieald(
                            hintText: "Search something...",
                            suffixIcon: IconButton(
                              icon: Image.asset(
                                ConstanceData.h4,
                                height: 25,
                              ),
                              onPressed: () {},
                            ),
                            click: () {}),
                        SizedBox(
                          height: 30,
                        ),
                        Expanded(
                          child: ListView(
                            padding: EdgeInsets.zero,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => ChatConvesationScreen(),
                                    ),
                                  );
                                },
                                child: Stack(
                                  alignment: Alignment.topRight,
                                  children: [
                                    Row(
                                      children: [
                                        Image.asset(
                                          ConstanceData.h31,
                                          height: 50,
                                        ),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Michele",
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .displayLarge!
                                                  .copyWith(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                              "Nulla Lorem mollit cupidatat irure. ",
                                              textAlign: TextAlign.center,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .displayLarge!
                                                  .copyWith(
                                                      fontSize: 12,
                                                      color: Theme.of(context)
                                                          .disabledColor),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                    Column(
                                      children: [
                                        CircleAvatar(
                                          radius: 10,
                                          backgroundColor:
                                              Theme.of(context).primaryColor,
                                          child: Text(
                                            "1",
                                            style: Theme.of(context)
                                                .textTheme
                                                .displayLarge!
                                                .copyWith(
                                                    fontSize: 12,
                                                    color: Colors.white),
                                          ),
                                        ),
                                        SizedBox(
                                          height: 8,
                                        ),
                                        Text(
                                          "19.00",
                                          textAlign: TextAlign.center,
                                          style: Theme.of(context)
                                              .textTheme
                                              .displayLarge!
                                              .copyWith(
                                                  fontSize: 10,
                                                  color: Theme.of(context)
                                                      .disabledColor),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 30,
                              ),
                              com(
                                  ConstanceData.h23,
                                  ConstanceData.v16,
                                  "Steve Julian",
                                  "Nulla Lorem mollit cupidatat irure. "),
                              SizedBox(
                                height: 30,
                              ),
                              com(
                                  ConstanceData.h22,
                                  ConstanceData.v17,
                                  "Julia Gomez",
                                  "Nulla Lorem mollit cupidatat irure. "),
                              SizedBox(
                                height: 30,
                              ),
                              com(ConstanceData.v19, ConstanceData.v18, "Laura",
                                  "Nulla Lorem mollit cupidatat irure. "),
                              SizedBox(
                                height: 30,
                              ),
                              com(ConstanceData.v15, ConstanceData.v16, "Max ",
                                  "Nulla Lorem mollit cupidatat irure. "),
                              SizedBox(
                                height: 30,
                              ),
                              com(ConstanceData.h32, ConstanceData.v16, "Chris",
                                  "Nulla Lorem mollit cupidatat irure. "),
                              SizedBox(
                                height: 30,
                              ),
                              com(
                                  ConstanceData.v14,
                                  ConstanceData.v16,
                                  "Maya Aliyah",
                                  "Nulla Lorem mollit cupidatat irure. "),
                              SizedBox(
                                height: 30,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                )));
      },
    );
  }

  Widget com(String img1, String img2, String tex1, String tex2) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChatConvesationScreen(),
          ),
        );
      },
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Row(
            children: [
              Image.asset(
                img1,
                height: 50,
              ),
              SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    tex1,
                    style: Theme.of(context)
                        .textTheme
                        .displayLarge!
                        .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    tex2,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 12, color: Theme.of(context).disabledColor),
                  ),
                ],
              )
            ],
          ),
          Column(
            children: [
              Image.asset(
                img2,
                height: 20,
              ),
              SizedBox(
                height: 8,
              ),
              Text(
                "19.00",
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.displayLarge!.copyWith(
                    fontSize: 10, color: Theme.of(context).disabledColor),
              ),
            ],
          )
        ],
      ),
    );
  }
}
