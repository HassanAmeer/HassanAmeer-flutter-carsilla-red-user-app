// ignore_for_file: deprecated_member_use, library_private_types_in_public_api, avoid_unnecessary_containers, sized_box_for_whitespace, constant_identifier_names, prefer_const_constructors, avoid_single_cascade_in_expression_statements

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Explore/6.4_stories_camera.dart';
import 'package:autocar/Explore/explore.dart';
import 'package:autocar/Message/message_screen.dart';
import 'package:autocar/Profile/profile_screen.dart';
import 'package:autocar/home/home_screen.dart';
import 'package:flutter/material.dart';

class PageScreen extends StatefulWidget {
  const PageScreen({super.key});

  @override
  _PageScreenState createState() => _PageScreenState();
}

class _PageScreenState extends State<PageScreen> with TickerProviderStateMixin {
  late AnimationController animationController;
  late Widget indexView;
  BottomBarType bottomBarType = BottomBarType.Home;

  @override
  void initState() {
    animationController =
        AnimationController(duration: Duration(milliseconds: 400), vsync: this);
    indexView = HomeScreen(
      animationController: animationController,
    );
    animationController..forward();
    super.initState();
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
        backgroundColor: AppTheme.getTheme().backgroundColor,
        bottomNavigationBar: Container(
            height: 70 + MediaQuery.of(context).padding.bottom,
            child: getBottomBarUI(bottomBarType)),
        body: indexView,
      ),
    );
  }

  void tabClick(BottomBarType tabType) {
    if (tabType != bottomBarType) {
      bottomBarType = tabType;
      animationController.reverse().then((f) {
        if (tabType == BottomBarType.Home) {
          setState(() {
            indexView = HomeScreen(
              animationController: animationController,
            );
          });
        } else if (tabType == BottomBarType.Explore) {
          setState(() {
            indexView = ExploreScreen(
              animationController: animationController,
            );
          });
        } else if (tabType == BottomBarType.plus) {
          setState(() {
            indexView = StoriesCameraScreen(
              animationController: animationController,
            );
          });
        } else if (tabType == BottomBarType.message) {
          setState(() {
            indexView = MessageScreen(
              animationController: animationController,
            );
          });
        } else if (tabType == BottomBarType.Profile) {
          setState(() {
            indexView = ProfileScreen(
              animationController: animationController,
            );
          });
        }
      });
    }
  }

  Widget getBottomBarUI(BottomBarType tabType) {
    return Container(
      // height: 70 + MediaQuery.of(context).padding.bottom,
      decoration: BoxDecoration(
        color:
            AppTheme.isLightTheme ? HexColor("#FFFFFF") : HexColor("#111827"),
        // ignore: prefer_const_literals_to_create_immutables
        boxShadow: [
          BoxShadow(
            color: Colors.grey,
            blurRadius: 1,
            spreadRadius: 2,
            offset: Offset(5.0, 5.0),
          )
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.only(right: 24, left: 24, bottom: 18),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              onTap: () {
                tabClick(BottomBarType.Home);
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    ConstanceData.s14,
                    color: tabType == BottomBarType.Home
                        ? Theme.of(context).primaryColor
                        : Theme.of(context).disabledColor,
                    height: 26,
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "Home",
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: tabType == BottomBarType.Home
                              ? Theme.of(context).primaryColor
                              : Theme.of(context).disabledColor,
                        ),
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                tabClick(BottomBarType.Explore);
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    ConstanceData.s15,
                    color: tabType == BottomBarType.Explore
                        ? Theme.of(context).primaryColor
                        : Theme.of(context).disabledColor,
                    height: 26,
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "Explore",
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: tabType == BottomBarType.Explore
                              ? Theme.of(context).primaryColor
                              : Theme.of(context).disabledColor,
                        ),
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                tabClick(
                  BottomBarType.plus,
                );
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: Theme.of(context).primaryColor,
                    child: Image.asset(
                      ConstanceData.s16,
                      height: 20,
                    ),
                  ),
                ],
              ),
            ),
            InkWell(
              onTap: () {
                tabClick(
                  BottomBarType.message,
                );
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    ConstanceData.s17,
                    color: tabType == BottomBarType.message
                        ? Theme.of(context).primaryColor
                        : Theme.of(context).disabledColor,
                    height: 26,
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "Message",
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: tabType == BottomBarType.message
                              ? Theme.of(context).primaryColor
                              : Theme.of(context).disabledColor,
                        ),
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                tabClick(BottomBarType.Profile);
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    ConstanceData.s18,
                    height: 26,
                    color: tabType == BottomBarType.Profile
                        ? Theme.of(context).primaryColor
                        : Theme.of(context).disabledColor,
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "Profile",
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: tabType == BottomBarType.Profile
                              ? Theme.of(context).primaryColor
                              : Theme.of(context).disabledColor,
                        ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

enum BottomBarType {
  Home,
  Explore,
  plus,
  message,
  Profile,
}
