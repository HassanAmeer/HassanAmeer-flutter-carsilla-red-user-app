// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/Widget/textFiealds.dart';
import 'package:flutter/material.dart';

class Transaction2Screen extends StatefulWidget {
  const Transaction2Screen({super.key});

  @override
  State<Transaction2Screen> createState() => _Transaction2ScreenState();
}

class _Transaction2ScreenState extends State<Transaction2Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom + 16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s6
                        : ConstanceData.ds6,
                    height: 25,
                  ),
                ),
                Text(
                  "Set Filter",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Row(
                    children: [
                      Text(
                        "Location",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  MyTextFieald(
                      hintText: "Jakarta, Indonesia",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.h3,
                          height: 25,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v24,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text(
                        "Brand",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  MyTextFieald(
                      hintText: "Tesla",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v25,
                          height: 25,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v24,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text(
                        "Color",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  MyTextFieald(
                      hintText: "All Color",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v26,
                          height: 25,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v24,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text(
                        "Year",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    height: 40,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 80,
                              decoration: BoxDecoration(
                                color: Theme.of(context).primaryColor,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "2021",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Container(
                              width: 80,
                              decoration: BoxDecoration(
                                color: AppTheme.isLightTheme
                                    ? HexColor("#EFF4FF")
                                    : HexColor("#1E293B"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "2020",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).disabledColor,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Container(
                              width: 80,
                              decoration: BoxDecoration(
                                color: AppTheme.isLightTheme
                                    ? HexColor("#EFF4FF")
                                    : HexColor("#1E293B"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "2019",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).disabledColor,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Container(
                              width: 80,
                              decoration: BoxDecoration(
                                color: AppTheme.isLightTheme
                                    ? HexColor("#EFF4FF")
                                    : HexColor("#1E293B"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "2018",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).disabledColor,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Container(
                              width: 80,
                              decoration: BoxDecoration(
                                color: AppTheme.isLightTheme
                                    ? HexColor("#EFF4FF")
                                    : HexColor("#1E293B"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "2017",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).disabledColor,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text(
                        "Price",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text(
                        "\$50,522 - \$99,999",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.v27
                        : ConstanceData.dv27,
                    width: MediaQuery.of(context).size.width,
                    fit: BoxFit.fill,
                  )
                ],
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                      border: Border.all(color: Theme.of(context).primaryColor),
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Center(
                      child: Text(
                        "Reset",
                        style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).primaryColor,
                            ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 20,
                ),
                Expanded(
                  child: MyButton(
                      btnName: "Done",
                      click: () {
                        Navigator.pop(context);
                      }),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            )
          ],
        ),
      ),
    );
  }
}
