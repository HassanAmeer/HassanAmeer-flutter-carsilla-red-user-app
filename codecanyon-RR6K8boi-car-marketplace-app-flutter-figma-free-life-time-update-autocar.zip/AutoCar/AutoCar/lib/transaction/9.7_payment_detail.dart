// ignore_for_file: prefer_const_constructors

import 'package:autocar/transaction/9.8_payment_method.dart';
import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/Widget/textFiealds.dart';
import 'package:flutter/material.dart';

class PaymentDetailScreen extends StatefulWidget {
  const PaymentDetailScreen({super.key});

  @override
  State<PaymentDetailScreen> createState() => _PaymentDetailScreenState();
}

class _PaymentDetailScreenState extends State<PaymentDetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom + 16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s1
                        : ConstanceData.ds1,
                    height: 25,
                  ),
                ),
                Text(
                  "Payment Detail",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Row(
                    children: [
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                          color: AppTheme.isLightTheme
                              ? HexColor("#EFF4FF")
                              : HexColor("#1E293B"),
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                           AppTheme.isLightTheme
                                  ? ConstanceData.v10
                                  : ConstanceData.dv10,
                              height: 30,
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Tesla Model S",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            "Est. Delivery: June 2022 ",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12,
                                    color: Theme.of(context).disabledColor),
                          )
                        ],
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  MyTextFieald(
                      hintText: "Pearl White Multi-Coat",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v34,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          AppTheme.isLightTheme
                              ? ConstanceData.h1
                              : ConstanceData.dh1,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 30,
                  ),
                  MyTextFieald(
                      hintText: "Jl. Sukarno Hatta 211/B45",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v35,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 30,
                  ),
                  MyTextFieald(
                      hintText: "Jakarta, Indonesia",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v36,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          AppTheme.isLightTheme
                              ? ConstanceData.h1
                              : ConstanceData.dh1,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 30,
                  ),
                  MyTextFieald(
                      hintText: "081332864328",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v37,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 30,
                  ),
                  MyTextFieald(
                      hintText: "Mark Lawson",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v38,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {})
                ],
              ),
            ),
            MyButton(
                btnName: "Continue",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PaymentMethodScreen(),
                    ),
                  );
                })
          ],
        ),
      ),
    );
  }
}
