// ignore_for_file: prefer_const_constructors

import 'package:autocar/transaction/9.5_transaction_proccess.dart';
import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/Widget/textFiealds.dart';
import 'package:flutter/material.dart';

class Trasaction4Screen extends StatefulWidget {
  const Trasaction4Screen({super.key});

  @override
  State<Trasaction4Screen> createState() => _Trasaction4ScreenState();
}

class _Trasaction4ScreenState extends State<Trasaction4Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom + 16),
        child: Column(
          children: [
            Row(
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s6
                        : ConstanceData.ds6,
                    height: 25,
                  ),
                )
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Row(
                    children: [
                      Text(
                        "Enter an offer for",
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                          color: AppTheme.isLightTheme
                              ? HexColor("#EFF4FF")
                              : HexColor("#1E293B"),
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                               AppTheme.isLightTheme
                                  ? ConstanceData.v10
                                  : ConstanceData.dv10,
                              height: 30,
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Tesla Model S",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              Image.asset(
                                ConstanceData.h3,
                                height: 20,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                "Jakarta, Indonesia",
                                style: Theme.of(context)
                                    .textTheme
                                    .displayLarge!
                                    .copyWith(
                                        fontSize: 12,
                                        color: Theme.of(context).disabledColor),
                              ),
                            ],
                          )
                        ],
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  MyTextFieald(
                      hintText: "amount",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v31,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 35,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 80,
                              height: 35,
                              decoration: BoxDecoration(
                                color: AppTheme.isLightTheme
                                    ? HexColor("#EFF4FF")
                                    : HexColor("#1E293B"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "88,740",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Container(
                              width: 80,
                              decoration: BoxDecoration(
                                color: AppTheme.isLightTheme
                                    ? HexColor("#EFF4FF")
                                    : HexColor("#1E293B"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "88,800",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Container(
                              width: 80,
                              decoration: BoxDecoration(
                                color: AppTheme.isLightTheme
                                    ? HexColor("#EFF4FF")
                                    : HexColor("#1E293B"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "88,900",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Container(
                              width: 80,
                              decoration: BoxDecoration(
                                color: AppTheme.isLightTheme
                                    ? HexColor("#EFF4FF")
                                    : HexColor("#1E293B"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "99.00",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Container(
                              width: 80,
                              decoration: BoxDecoration(
                                color: AppTheme.isLightTheme
                                    ? HexColor("#EFF4FF")
                                    : HexColor("#1E293B"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                              ),
                              child: Center(
                                child: Text(
                                  "2017",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge!
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            MyButton(
                btnName: "Send Offer",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => TrasactionProccessScreen(),
                    ),
                  );
                })
          ],
        ),
      ),
    );
  }
}
