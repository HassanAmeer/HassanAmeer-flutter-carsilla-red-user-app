// ignore_for_file: prefer_const_constructors

import 'package:autocar/transaction/9.6_transaction_accepted.dart';
import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:flutter/material.dart';

class TrasactionProccessScreen extends StatefulWidget {
  const TrasactionProccessScreen({super.key});

  @override
  State<TrasactionProccessScreen> createState() =>
      _TrasactionProccessScreenState();
}

class _TrasactionProccessScreenState extends State<TrasactionProccessScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 20,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s6
                        : ConstanceData.ds6,
                    height: 25,
                  ),
                )
              ],
            ),
            Expanded(child: SizedBox()),
            Image.asset(
              AppTheme.isLightTheme ? ConstanceData.v32 : ConstanceData.dv32,
              height: 120,
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Your offer is being\nprocessed",
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .displayLarge!
                  .copyWith(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "Your offer is being processed, check \nthe notification to see if your offer was \naccepted or rejected",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 12, color: Theme.of(context).disabledColor),
            ),
            Expanded(child: SizedBox()),
            MyButton(
                btnName: "Back to Home",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => TrasactionAcceptedScreen(),
                    ),
                  );
                }),
            SizedBox(
              height: 30,
            )
          ],
        ),
      ),
    );
  }
}
