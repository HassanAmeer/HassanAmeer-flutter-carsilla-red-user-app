// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/Widget/pageview.dart';
import 'package:flutter/material.dart';

class Transaction5Screen extends StatefulWidget {
  const Transaction5Screen({super.key});

  @override
  State<Transaction5Screen> createState() => _Transaction5ScreenState();
}

class _Transaction5ScreenState extends State<Transaction5Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 20,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s6
                        : ConstanceData.ds6,
                    height: 25,
                  ),
                )
              ],
            ),
            Expanded(child: SizedBox()),
            Image.asset(
              AppTheme.isLightTheme ? ConstanceData.v49 : ConstanceData.dv49,
              height: 120,
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Payment Success",
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .displayLarge!
                  .copyWith(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "Your payment has been successful, \nplease wait for your dream car \nto come to your house",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 12, color: Theme.of(context).disabledColor),
            ),
            Expanded(child: SizedBox()),
            MyButton(
                btnName: "Back to Home",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PageScreen(),
                    ),
                  );
                }),
            SizedBox(
              height: 30,
            )
          ],
        ),
      ),
    );
  }
}
