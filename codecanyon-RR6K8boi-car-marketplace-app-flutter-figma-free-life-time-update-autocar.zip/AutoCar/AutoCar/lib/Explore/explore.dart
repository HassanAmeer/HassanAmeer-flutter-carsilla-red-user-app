// ignore_for_file: prefer_const_constructors, annotate_overrides, unnecessary_new

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Explore/6.2_explore_comment.dart';
import 'package:autocar/Explore/6.5_stories_preview.dart';
import 'package:autocar/Explore/6.6_article_posting.dart';
import 'package:autocar/Widget/textFiealds.dart';
import 'package:flutter/material.dart';

class ExploreScreen extends StatefulWidget {
  final AnimationController animationController;

  const ExploreScreen({super.key, required this.animationController});

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late ScrollController controller;
  bool isLoadingSliderDetail = false;
  var sliderImageHieght = 0.0;
  void initState() {
    _animationController =
        AnimationController(duration: Duration(milliseconds: 0), vsync: this);
    widget.animationController.forward();
    controller = ScrollController(initialScrollOffset: 0.0);

    controller.addListener(() {
      // ignore: unnecessary_null_comparison
      if (context != null) {
        if (controller.offset < 0) {
          _animationController.animateTo(0.0);
        } else if (controller.offset > 0.0 &&
            controller.offset < sliderImageHieght) {
          if (controller.offset < ((sliderImageHieght / 1.5))) {
            _animationController
                .animateTo((controller.offset / sliderImageHieght));
          } else {
            _animationController
                .animateTo((sliderImageHieght / 1.5) / sliderImageHieght);
          }
        }
      }
    });
    loadingSliderDetail();
    super.initState();
  }

  loadingSliderDetail() async {
    setState(() {
      isLoadingSliderDetail = true;
    });
    await Future.delayed(const Duration(milliseconds: 700));
    setState(() {
      isLoadingSliderDetail = false;
    });
  }

  bool isdark = false;
  int index = 0;
  @override
  Widget build(BuildContext context) {
    sliderImageHieght = MediaQuery.of(context).size.width * 1.3;
    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget? child) {
        return FadeTransition(
            opacity: widget.animationController,
            child: Transform(
                transform: new Matrix4.translationValues(
                  0.0,
                  40 * (1.0 - widget.animationController.value),
                  0.0,
                ),
                child: Scaffold(
                  body: Padding(
                    padding: EdgeInsets.only(
                        left: 16,
                        right: 16,
                        top: MediaQuery.of(context).padding.top + 16,
                        bottom: MediaQuery.of(context).padding.bottom + 16),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => ArticlePostingScreen(),
                                  ),
                                );
                              },
                              child: Image.asset(
                                AppTheme.isLightTheme
                                    ? ConstanceData.h16
                                    : ConstanceData.dh16,
                                height: 25,
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                showModalBottomSheet(
                                  context: context,
                                  builder: (builder) {
                                    return Container(
                                      height: 400,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(30),
                                            topRight: Radius.circular(30)),
                                        color: Theme.of(context)
                                            .scaffoldBackgroundColor,
                                      ),
                                      child: ListView(
                                        children: [
                                          Padding(
                                              padding: const EdgeInsets.all(20),
                                              child: Column(
                                                children: [
                                                  Container(
                                                    height: 4,
                                                    width: 50,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  30)),
                                                      color: Theme.of(context)
                                                          .disabledColor,
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 30,
                                                  ),
                                                  MyTextFieald(
                                                      hintText:
                                                          "Search something...",
                                                      suffixIcon: IconButton(
                                                        icon: Image.asset(
                                                          ConstanceData.h4,
                                                          height: 20,
                                                        ),
                                                        onPressed: () {},
                                                      ),
                                                      click: () {}),
                                                  SizedBox(
                                                    height: 30,
                                                  ),
                                                  com(ConstanceData.h23,
                                                      "Steve Julian"),
                                                  SizedBox(
                                                    height: 20,
                                                  ),
                                                  com(ConstanceData.h32,
                                                      "Rendy"),
                                                  SizedBox(
                                                    height: 20,
                                                  ),
                                                  com(ConstanceData.h22,
                                                      "Julia Gomez"),
                                                  SizedBox(
                                                    height: 20,
                                                  ),
                                                  com(ConstanceData.h31,
                                                      "Michele")
                                                ],
                                              ))
                                        ],
                                      ),
                                    );
                                  },
                                );
                              },
                              child: Image.asset(
                                AppTheme.isLightTheme
                                    ? ConstanceData.h17
                                    : ConstanceData.dh17,
                                height: 25,
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => StoriesPreviewScreen(),
                                  ),
                                );
                              },
                              child: Column(
                                children: [
                                  Image.asset(
                                    ConstanceData.h18,
                                    height: 50,
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text(
                                    "You",
                                    style: Theme.of(context)
                                        .textTheme
                                        .displayLarge!
                                        .copyWith(
                                          fontSize: 12,
                                        ),
                                  ),
                                ],
                              ),
                            ),
                            Column(
                              children: [
                                Image.asset(
                                  ConstanceData.h19,
                                  height: 50,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "Michele",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Image.asset(
                                  ConstanceData.h20,
                                  height: 50,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "Steve",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Image.asset(
                                  ConstanceData.h21,
                                  height: 50,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "Laura",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Image.asset(
                                  ConstanceData.h22,
                                  height: 50,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "Julia",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ],
                            )
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Divider(),
                        SizedBox(
                          height: 10,
                        ),
                        Expanded(
                          child: ListView(
                            padding: EdgeInsets.zero,
                            children: [
                              Row(
                                children: [
                                  Image.asset(
                                    ConstanceData.h23,
                                    height: 50,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Steve Julian",
                                        style: Theme.of(context)
                                            .textTheme
                                            .displayLarge!
                                            .copyWith(
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold),
                                      ),
                                      SizedBox(
                                        height: 2,
                                      ),
                                      Text(
                                        "20 min ago",
                                        style: Theme.of(context)
                                            .textTheme
                                            .displayLarge!
                                            .copyWith(
                                                fontSize: 12,
                                                color: Theme.of(context)
                                                    .disabledColor),
                                      ),
                                    ],
                                  ),
                                  Spacer(),
                                  Image.asset(
                                    AppTheme.isLightTheme
                                        ? ConstanceData.h24
                                        : ConstanceData.dh24,
                                    height: 25,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Image.asset(
                                ConstanceData.h26,
                                width: MediaQuery.of(context).size.width,
                                fit: BoxFit.cover,
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Text(
                                "The Best Car 2021",
                                style: Theme.of(context)
                                    .textTheme
                                    .displayLarge!
                                    .copyWith(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Text(
                                "Nulla Lorem mollit cupidatat irure. Laborum magna nulla duis ullamco cillum dolor. Voluptate exercitation incididunt aliquip deserunt reprehenderit elit laborum. ",
                                style: Theme.of(context)
                                    .textTheme
                                    .displayLarge!
                                    .copyWith(
                                      fontSize: 12,
                                    ),
                              ),
                              Text(
                                "Read More...",
                                style: Theme.of(context)
                                    .textTheme
                                    .displayLarge!
                                    .copyWith(
                                        fontSize: 12,
                                        color: Theme.of(context).primaryColor),
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Row(
                                children: [
                                  Image.asset(
                                    ConstanceData.h12,
                                    height: 20,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    "12K",
                                    style: Theme.of(context)
                                        .textTheme
                                        .displayLarge!
                                        .copyWith(
                                          fontSize: 14,
                                        ),
                                  ),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) =>
                                              ExploreCommentScreen(),
                                        ),
                                      );
                                    },
                                    child: Image.asset(
                                      ConstanceData.h27,
                                      height: 20,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    "2K",
                                    style: Theme.of(context)
                                        .textTheme
                                        .displayLarge!
                                        .copyWith(
                                          fontSize: 14,
                                        ),
                                  ),
                                  Spacer(),
                                  Image.asset(
                                    AppTheme.isLightTheme
                                        ? ConstanceData.h28
                                        : ConstanceData.dh28,
                                    height: 30,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Divider(),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  Image.asset(
                                    ConstanceData.h22,
                                    height: 50,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Julia Gomez",
                                        style: Theme.of(context)
                                            .textTheme
                                            .displayLarge!
                                            .copyWith(
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold),
                                      ),
                                      SizedBox(
                                        height: 2,
                                      ),
                                      Text(
                                        "20 min ago",
                                        style: Theme.of(context)
                                            .textTheme
                                            .displayLarge!
                                            .copyWith(
                                                fontSize: 12,
                                                color: Theme.of(context)
                                                    .disabledColor),
                                      ),
                                    ],
                                  ),
                                  Spacer(),
                                  Image.asset(
                                    AppTheme.isLightTheme
                                        ? ConstanceData.h24
                                        : ConstanceData.dh24,
                                    height: 25,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Image.asset(
                                ConstanceData.h29,
                                width: MediaQuery.of(context).size.width,
                                fit: BoxFit.cover,
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Text(
                                "The Best Car 2021",
                                style: Theme.of(context)
                                    .textTheme
                                    .displayLarge!
                                    .copyWith(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Text(
                                "Nulla Lorem mollit cupidatat irure. Laborum magna nulla duis ullamco cillum dolor. Voluptate exercitation incididunt aliquip deserunt reprehenderit elit laborum. ",
                                style: Theme.of(context)
                                    .textTheme
                                    .displayLarge!
                                    .copyWith(
                                      fontSize: 12,
                                    ),
                              ),
                              Text(
                                "Read More...",
                                style: Theme.of(context)
                                    .textTheme
                                    .displayLarge!
                                    .copyWith(
                                        fontSize: 12,
                                        color: Theme.of(context).primaryColor),
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Row(
                                children: [
                                  Image.asset(
                                    ConstanceData.h12,
                                    height: 20,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    "12K",
                                    style: Theme.of(context)
                                        .textTheme
                                        .displayLarge!
                                        .copyWith(
                                          fontSize: 14,
                                        ),
                                  ),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) =>
                                              ExploreCommentScreen(),
                                        ),
                                      );
                                    },
                                    child: Image.asset(
                                      ConstanceData.h27,
                                      height: 20,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    "12K",
                                    style: Theme.of(context)
                                        .textTheme
                                        .displayLarge!
                                        .copyWith(
                                          fontSize: 14,
                                        ),
                                  ),
                                  Spacer(),
                                  Image.asset(
                                    AppTheme.isLightTheme
                                        ? ConstanceData.h28
                                        : ConstanceData.dh28,
                                    height: 30,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                )));
      },
    );
  }

  Widget com(String img, String tex) {
    return Row(
      children: [
        Image.asset(
          img,
          height: 40,
        ),
        SizedBox(
          width: 10,
        ),
        Text(
          tex,
          style: Theme.of(context)
              .textTheme
              .displayLarge!
              .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
        ),
        Spacer(),
        Image.asset(
          AppTheme.isLightTheme ? ConstanceData.h28 : ConstanceData.dh28,
          height: 25,
        ),
      ],
    );
  }
}
