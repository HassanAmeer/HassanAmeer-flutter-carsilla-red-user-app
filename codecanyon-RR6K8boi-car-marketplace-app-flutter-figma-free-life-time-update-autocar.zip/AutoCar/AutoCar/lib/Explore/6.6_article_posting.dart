// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Explore/6.7_article_success.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:flutter/material.dart';

class ArticlePostingScreen extends StatefulWidget {
  const ArticlePostingScreen({super.key});

  @override
  State<ArticlePostingScreen> createState() => _ArticlePostingScreenState();
}

class _ArticlePostingScreenState extends State<ArticlePostingScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom + 16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s1
                        : ConstanceData.ds1,
                    height: 25,
                  ),
                ),
                Text(
                  "Upload Article",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.h40
                        : ConstanceData.dh40,
                    fit: BoxFit.cover,
                    width: MediaQuery.of(context).size.width,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    "Title goes here",
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 14,
                        color: HexColor("#94A3B8"),
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    height: 110,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Theme.of(context).dividerColor,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Text(
                        "Nulla Lorem mollit cupidatat irure. Laborum magna nulla duis ullamco cillum dolor. Voluptate exercitation incididunt aliquip deserunt reprehenderit elit laborum. irure tempor cupidatat incididunt sint|",
                        style:
                            Theme.of(context).textTheme.displayLarge!.copyWith(
                                  fontSize: 12,
                                ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            MyButton(
                btnName: "Upload",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ArticleSuccessScreen(),
                    ),
                  );
                }),
          ],
        ),
      ),
    );
  }
}
