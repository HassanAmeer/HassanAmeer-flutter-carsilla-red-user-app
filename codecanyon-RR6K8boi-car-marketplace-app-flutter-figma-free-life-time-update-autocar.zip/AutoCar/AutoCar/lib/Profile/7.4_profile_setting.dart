// ignore_for_file: prefer_const_constructors, non_constant_identifier_names

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Profile/7.5_profile_notification.dart';
import 'package:autocar/Profile/7.6_profile_transaction_history.dart';
import 'package:autocar/Profile/7.7_profile_account_preference.dart';
import 'package:autocar/Profile/7.8_profile_about_us.dart';
import 'package:autocar/auth/sign_In.dart';
import 'package:autocar/main.dart';
import 'package:autocar/selling/10.1_selling_step_1.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ProfileSettingScreen extends StatefulWidget {
  const ProfileSettingScreen({super.key});

  @override
  State<ProfileSettingScreen> createState() => _ProfileSettingScreenState();
}

class _ProfileSettingScreenState extends State<ProfileSettingScreen> {
  bool isdark = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom + 40),
        child: Column(children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Image.asset(
                  AppTheme.isLightTheme ? ConstanceData.s1 : ConstanceData.ds1,
                  height: 20,
                ),
              ),
              Text(
                "Setting",
                style: Theme.of(context)
                    .textTheme
                    .displayLarge!
                    .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                width: 30,
              ),
            ],
          ),
          SizedBox(
            height: 30,
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                Row(
                  children: [
                    Text(
                      "General",
                      textAlign: TextAlign.start,
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12, color: Theme.of(context).disabledColor),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProgileNotificationScreen(),
                        ),
                      );
                    },
                    child: Com(ConstanceData.v1, "Notification")),
                SizedBox(
                  height: 20,
                ),
                InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfileTransactionHistoryScreen(),
                        ),
                      );
                    },
                    child: Com(ConstanceData.v3, "Transaction History")),
                SizedBox(
                  height: 20,
                ),
                InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProgileAccountPrefrenceScreen(),
                        ),
                      );
                    },
                    child: Com(ConstanceData.v4, "Account Preference")),
                SizedBox(
                  height: 20,
                ),
                InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => SellingStep1Screen(),
                        ),
                      );
                    },
                    child: Com(ConstanceData.v5, "General Information")),
                SizedBox(
                  height: 20,
                ),
                Row(
                  children: [
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: AppTheme.isLightTheme
                          ? HexColor("#EFF4FF")
                          : HexColor("#1E293"),
                      child: Image.asset(
                        ConstanceData.c15,
                        color: Theme.of(context).primaryColor,
                        height: 15,
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Night Mode",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                            fontSize: 14,
                          ),
                    ),
                    Spacer(),
                    CupertinoSwitch(
                      value: isdark,
                      activeColor: Theme.of(context).primaryColor,
                      onChanged: (bool? value) {
                        setState(() {
                          isdark = value!;
                        });
                        if (isdark) {
                          MyApp.setCustomeTheme(context, 7);
                        } else {
                          MyApp.setCustomeTheme(context, 6);
                        }
                      },
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Text(
                      "Other",
                      textAlign: TextAlign.start,
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12, color: Theme.of(context).disabledColor),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Com(ConstanceData.v6, "Help"),
                SizedBox(
                  height: 20,
                ),
                InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfileAboutUsScreen(),
                        ),
                      );
                    },
                    child: Com(ConstanceData.v7, "About Us")),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SignInScreen(),
                ),
              );
            },
            child: Container(
              height: 50,
              width: double.infinity,
              decoration: BoxDecoration(
                border: Border.all(color: HexColor("#E82627")),
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
              child: Center(
                child: Text(
                  "Log Out",
                  style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: HexColor("#E82627"),
                      ),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget Com(String img, String tex) {
    return Row(
      children: [
        CircleAvatar(
          radius: 20,
          backgroundColor:
              AppTheme.isLightTheme ? HexColor("#EFF4FF") : HexColor("#1E293"),
          child: Center(
            child: Image.asset(
              img,
              height: 15,
            ),
          ),
        ),
        SizedBox(
          width: 20,
        ),
        Text(
          tex,
          style: Theme.of(context).textTheme.displayLarge!.copyWith(
                fontSize: 14,
              ),
        ),
        Spacer(),
        Image.asset(
          ConstanceData.v2,
          height: 20,
        )
      ],
    );
  }
}
