// ignore_for_file: prefer_const_constructors, sort_child_properties_last

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:flutter/material.dart';

class ProfileTransactionHistoryScreen extends StatefulWidget {
  const ProfileTransactionHistoryScreen({super.key});

  @override
  State<ProfileTransactionHistoryScreen> createState() =>
      _ProfileTransactionHistoryScreenState();
}

class _ProfileTransactionHistoryScreenState
    extends State<ProfileTransactionHistoryScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s1
                        : ConstanceData.ds1,
                    height: 25,
                  ),
                ),
                Text(
                  "Transaction History",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Row(
                    children: [
                      Text(
                        "This Week",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  com(ConstanceData.v11),
                  SizedBox(
                    height: 30,
                  ),
                  com(ConstanceData.v12),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    children: [
                      Text(
                        "Last week",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  com(ConstanceData.v11),
                  SizedBox(
                    height: 30,
                  ),
                  com(ConstanceData.v12),
                  SizedBox(
                    height: 30,
                  ),
                  com(ConstanceData.v11),
                  SizedBox(
                    height: 30,
                  ),
                  com(ConstanceData.v12)
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget com(String img1) {
    return Row(
      children: [
        CircleAvatar(
          radius: 22,
          child: Image.asset(
            AppTheme.isLightTheme ? ConstanceData.v10 : ConstanceData.dv10,
            height: 20,
          ),
          backgroundColor:
              AppTheme.isLightTheme ? HexColor("#EFF4FF") : HexColor("#334155"),
        ),
        SizedBox(
          width: 10,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Tesla Model S",
              style: Theme.of(context)
                  .textTheme
                  .displayLarge!
                  .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 5,
            ),
            Text(
              "4 days ago",
              textAlign: TextAlign.start,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 12, color: Theme.of(context).disabledColor),
            ),
          ],
        ),
        Spacer(),
        Text(
          "\$130,000",
          style: Theme.of(context)
              .textTheme
              .displayLarge!
              .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          width: 10,
        ),
        Image.asset(
          img1,
          height: 23,
        )
      ],
    );
  }
}
