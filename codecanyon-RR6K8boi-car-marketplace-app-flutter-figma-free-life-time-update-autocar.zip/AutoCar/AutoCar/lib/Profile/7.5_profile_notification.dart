// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:flutter/material.dart';

class ProgileNotificationScreen extends StatefulWidget {
  const ProgileNotificationScreen({super.key});

  @override
  State<ProgileNotificationScreen> createState() =>
      _ProgileNotificationScreenState();
}

class _ProgileNotificationScreenState extends State<ProgileNotificationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                     onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme ? ConstanceData.s1 : ConstanceData.ds1,
                    height: 25,
                  ),
                ),
                Text(
                  "Notification",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Row(
                    children: [
                      Text(
                        "New",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  com(ConstanceData.h31, ConstanceData.v8, "Michele",
                      "Comment on your article"),
                  SizedBox(
                    height: 30,
                  ),
                  com(ConstanceData.h23, ConstanceData.v9, "Steve Julian",
                      "Like your article"),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text(
                        "Yesterday",
                        textAlign: TextAlign.start,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  com2(ConstanceData.h31, "Sarah",
                      "Reject your offer on Tesla Model 3"),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        ConstanceData.h22,
                        height: 50,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Julia Gomez",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 2,
                          ),
                          Text(
                            "Start following you",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                  fontSize: 12,
                                ),
                          ),
                          SizedBox(
                            height: 2,
                          ),
                          Text(
                            "5 min ago",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12,
                                    color: Theme.of(context).disabledColor),
                          ),
                        ],
                      ),
                      Spacer(),
                      Container(
                        height: 40,
                        width: 100,
                        decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Center(
                          child: Text(
                            "Follow",
                            style:
                                Theme.of(context).textTheme.bodyLarge!.copyWith(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  com(ConstanceData.h23, ConstanceData.v9, "Steve Julian",
                      "Like your article"),
                  SizedBox(
                    height: 30,
                  ),
                  com2(ConstanceData.v14, "Anisah",
                      "Accept your offer on Tesla Model S"),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        ConstanceData.v15,
                        height: 50,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Luke",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 2,
                          ),
                          Text(
                            "Start following you",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                  fontSize: 12,
                                ),
                          ),
                          SizedBox(
                            height: 2,
                          ),
                          Text(
                            "5 min ago",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12,
                                    color: Theme.of(context).disabledColor),
                          ),
                        ],
                      ),
                      Spacer(),
                      Container(
                        height: 40,
                        width: 100,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Theme.of(context).primaryColor,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Center(
                          child: Text(
                            "Follow",
                            style:
                                Theme.of(context).textTheme.bodyLarge!.copyWith(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).primaryColor,
                                    ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget com(String img1, String img2, String tex1, String tex2) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Image.asset(
          img1,
          height: 50,
        ),
        SizedBox(
          width: 10,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              tex1,
              style: Theme.of(context)
                  .textTheme
                  .displayLarge!
                  .copyWith(fontSize: 12, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 2,
            ),
            Text(
              tex2,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                    fontSize: 12,
                  ),
            ),
            SizedBox(
              height: 2,
            ),
            Text(
              "5 min ago",
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 12, color: Theme.of(context).disabledColor),
            ),
          ],
        ),
        Spacer(),
        Image.asset(
          img2,
          height: 60,
        )
      ],
    );
  }

  Widget com2(String img1, String tex1, String tex2) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Image.asset(
          img1,
          height: 50,
        ),
        SizedBox(
          width: 10,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              tex1,
              style: Theme.of(context)
                  .textTheme
                  .displayLarge!
                  .copyWith(fontSize: 12, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 2,
            ),
            Text(
              tex2,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                    fontSize: 12,
                  ),
            ),
            SizedBox(
              height: 2,
            ),
            Text(
              "5 min ago",
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 12, color: Theme.of(context).disabledColor),
            ),
          ],
        ),
      ],
    );
  }
}
