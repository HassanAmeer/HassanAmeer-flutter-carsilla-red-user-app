// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:flutter/material.dart';

class ProgileAccountPrefrenceScreen extends StatefulWidget {
  const ProgileAccountPrefrenceScreen({super.key});

  @override
  State<ProgileAccountPrefrenceScreen> createState() =>
      _ProgileAccountPrefrenceScreenState();
}

class _ProgileAccountPrefrenceScreenState
    extends State<ProgileAccountPrefrenceScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom + 16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                     onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme ? ConstanceData.s1 : ConstanceData.ds1,
                    height: 25,
                  ),
                ),
                Text(
                  "Account Preferences",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            com("Time Zone", "(GMT-4:00) Jakarta/Indonesia"),
            SizedBox(
              height: 30,
            ),
            com("Country", "Indonesia"),
            SizedBox(
              height: 30,
            ),
            com("Preferred Language", "English"),
            SizedBox(
              height: 30,
            ),
            com("Date Format", "MM/dd/yy"),
            SizedBox(
              height: 30,
            ),
            com("Email Verification", "Verified"),
            SizedBox(
              height: 30,
            ),
            com("Backup Email", "Mark.Lawson12345@gmail.com"),
          ],
        ),
      ),
    );
  }

  Widget com(String tex, String tex2) {
    return Row(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              tex,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                    fontSize: 14,
                  ),
            ),
            SizedBox(
              height: 5,
            ),
            Text(
              tex2,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 13, color: Theme.of(context).primaryColor),
            ),
          ],
        ),
        Spacer(),
        Image.asset(
          ConstanceData.v2,
          height: 25,
        )
      ],
    );
  }
}
