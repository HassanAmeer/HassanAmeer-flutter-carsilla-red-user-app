// ignore_for_file: prefer_const_constructors, annotate_overrides, unnecessary_new

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Profile/7.3_profile_sell.dart';
import 'package:autocar/Profile/7.4_profile_setting.dart';
import 'package:autocar/transaction/9.3_transaction3.dart';
import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  final AnimationController animationController;

  const ProfileScreen({super.key, required this.animationController});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late ScrollController controller;
  bool isLoadingSliderDetail = false;
  var sliderImageHieght = 0.0;
  void initState() {
    _animationController =
        AnimationController(duration: Duration(milliseconds: 0), vsync: this);
    widget.animationController.forward();
    controller = ScrollController(initialScrollOffset: 0.0);

    controller.addListener(() {
      // ignore: unnecessary_null_comparison
      if (context != null) {
        if (controller.offset < 0) {
          _animationController.animateTo(0.0);
        } else if (controller.offset > 0.0 &&
            controller.offset < sliderImageHieght) {
          if (controller.offset < ((sliderImageHieght / 1.5))) {
            _animationController
                .animateTo((controller.offset / sliderImageHieght));
          } else {
            _animationController
                .animateTo((sliderImageHieght / 1.5) / sliderImageHieght);
          }
        }
      }
    });
    loadingSliderDetail();
    super.initState();
  }

  loadingSliderDetail() async {
    setState(() {
      isLoadingSliderDetail = true;
    });
    await Future.delayed(const Duration(milliseconds: 700));
    setState(() {
      isLoadingSliderDetail = false;
    });
  }

  int pageNumber = 0;

  final PageController _pageController = PageController();
  bool isdark = false;
  int index = 0;
  @override
  Widget build(BuildContext context) {
    sliderImageHieght = MediaQuery.of(context).size.width * 1.3;
    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget? child) {
        return FadeTransition(
            opacity: widget.animationController,
            child: Transform(
                transform: new Matrix4.translationValues(
                  0.0,
                  40 * (1.0 - widget.animationController.value),
                  0.0,
                ),
                child: Scaffold(
                  body: Padding(
                    padding: EdgeInsets.only(
                        left: 16,
                        right: 16,
                        top: MediaQuery.of(context).padding.top + 16,
                        bottom: MediaQuery.of(context).padding.bottom + 16),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              width: 30,
                            ),
                            Text(
                              "Profile",
                              style: Theme.of(context)
                                  .textTheme
                                  .displayLarge!
                                  .copyWith(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold),
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => ProfileSettingScreen(),
                                  ),
                                );
                              },
                              child: Image.asset(
                                AppTheme.isLightTheme
                                    ? ConstanceData.dh36
                                    : ConstanceData.h36,
                                height: 20,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            Image.asset(
                              ConstanceData.h18,
                              height: 50,
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Mark Lawson",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Row(
                                  children: [
                                    Image.asset(
                                      ConstanceData.h3,
                                      height: 15,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "Jakarta, Indonesia",
                                      style: Theme.of(context)
                                          .textTheme
                                          .displayLarge!
                                          .copyWith(
                                              fontSize: 12,
                                              color: Theme.of(context)
                                                  .disabledColor),
                                    ),
                                  ],
                                )
                              ],
                            )
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                              children: [
                                Text(
                                  "105",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Post",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 12,
                                          color:
                                              Theme.of(context).disabledColor),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Text(
                                  "21,8K",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Following",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 12,
                                          color:
                                              Theme.of(context).disabledColor),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Text(
                                  "78,5K",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Followers",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 12,
                                          color:
                                              Theme.of(context).disabledColor),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Text(
                                  "215",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Sell",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 12,
                                          color:
                                              Theme.of(context).disabledColor),
                                ),
                              ],
                            )
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ProfileSellScreen(),
                              ),
                            );
                          },
                          child: Container(
                            height: 50,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Theme.of(context).primaryColor,
                              ),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                            ),
                            child: Center(
                              child: Text(
                                "Edit Profile",
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyLarge!
                                    .copyWith(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).primaryColor,
                                    ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            InkWell(
                              onTap: () {
                                setState(() {
                                  _pageController.jumpToPage(0);
                                });
                              },
                              child: Column(
                                children: [
                                  pageNumber == 0
                                      ? Image.asset(
                                          ConstanceData.h43,
                                          color: Theme.of(context).primaryColor,
                                          height: 30,
                                        )
                                      : Image.asset(
                                          ConstanceData.h43,
                                          height: 30,
                                        )
                                ],
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  _pageController.jumpToPage(1);
                                });
                              },
                              child: Column(
                                children: [
                                  pageNumber == 1
                                      ? Image.asset(
                                          ConstanceData.h44,
                                          color: Theme.of(context).primaryColor,
                                          height: 30,
                                        )
                                      : Image.asset(
                                          ConstanceData.h44,
                                          height: 30,
                                        )
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: pageNumber == 0
                                  ? Container(
                                      height: 2,
                                      width: double.infinity,
                                      color: Theme.of(context).primaryColor,
                                    )
                                  : Container(
                                      height: 2,
                                      width: double.infinity,
                                      color: Theme.of(context).dividerColor,
                                    ),
                            ),
                            Expanded(
                              child: pageNumber == 1
                                  ? Container(
                                      height: 2,
                                      width: double.infinity,
                                      color: Theme.of(context).primaryColor,
                                    )
                                  : Container(
                                      height: 2,
                                      width: double.infinity,
                                      color: Theme.of(context).dividerColor,
                                    ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Expanded(
                          flex: 2,
                          child: PageView(
                            controller: _pageController,
                            physics: BouncingScrollPhysics(),
                            onPageChanged: (value) {
                              setState(() {
                                pageNumber = value;
                              });
                            },
                            children: [
                              // ***********************
                              ListView(
                                padding: EdgeInsets.zero,
                                children: [
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          children: [
                                            Image.asset(
                                              ConstanceData.h45,
                                            ),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  "The most luxury...",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .displayLarge!
                                                      .copyWith(
                                                        fontSize: 12,
                                                      ),
                                                ),
                                                Image.asset(
                                                  AppTheme.isLightTheme
                                                      ? ConstanceData.h24
                                                      : ConstanceData.dh24,
                                                  height: 15,
                                                )
                                              ],
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Image.asset(
                                              ConstanceData.h47,
                                            ),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  "The most luxury...",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .displayLarge!
                                                      .copyWith(
                                                        fontSize: 12,
                                                      ),
                                                ),
                                                Image.asset(
                                                  AppTheme.isLightTheme
                                                      ? ConstanceData.h24
                                                      : ConstanceData.dh24,
                                                  height: 15,
                                                )
                                              ],
                                            )
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        width: 15,
                                      ),
                                      Expanded(
                                        child: Column(
                                          children: [
                                            Image.asset(
                                              ConstanceData.h46,
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  "Top 5 fastest car...",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .displayLarge!
                                                      .copyWith(
                                                        fontSize: 12,
                                                      ),
                                                ),
                                                Image.asset(
                                                  AppTheme.isLightTheme
                                                      ? ConstanceData.h24
                                                      : ConstanceData.dh24,
                                                  height: 15,
                                                )
                                              ],
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Image.asset(
                                              ConstanceData.h48,
                                            ),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  "The most luxury...",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .displayLarge!
                                                      .copyWith(
                                                        fontSize: 12,
                                                      ),
                                                ),
                                                Image.asset(
                                                  AppTheme.isLightTheme
                                                      ? ConstanceData.h24
                                                      : ConstanceData.dh24,
                                                  height: 15,
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 20,
                                  )
                                ],
                              ),
                              // *******************
                              ListView(
                                padding: EdgeInsets.zero,
                                children: [
                                  Row(
                                    children: [
                                      com2(ConstanceData.h12, ConstanceData.h13,
                                          "New", "Tesla Model S"),
                                      SizedBox(
                                        width: 15,
                                      ),
                                      com2(ConstanceData.h11, ConstanceData.h14,
                                          "Used", "Tesla Model 3"),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    children: [
                                      com2(ConstanceData.h11, ConstanceData.h13,
                                          "New", "Tesla Model S"),
                                      SizedBox(
                                        width: 15,
                                      ),
                                      com2(ConstanceData.h11, ConstanceData.h15,
                                          "New", "Tesla Model S"),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 20,
                                  )
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                )));
      },
    );
  }

  Widget com2(String img, String img2, String tex1, String tex2) {
    return Expanded(
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => Transaction3Screen(),
            ),
          );
        },
        child: Container(
          height: 180,
          decoration: BoxDecoration(
            border: Border.all(
              color: Theme.of(context).dividerColor,
            ),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      height: 25,
                      width: 70,
                      decoration: BoxDecoration(
                        color: AppTheme.isLightTheme
                            ? HexColor("#EFF4FF")
                            : Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(30)),
                      ),
                      child: Center(
                        child: Text(
                          tex1,
                          style:
                              Theme.of(context).textTheme.bodyLarge!.copyWith(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor,
                                  ),
                        ),
                      ),
                    ),
                    Spacer(),
                    Image.asset(
                      img,
                      height: 20,
                    )
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Image.asset(
                  img2,
                  height: 70,
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tex2,
                          textAlign: TextAlign.center,
                          style: Theme.of(context)
                              .textTheme
                              .displayLarge!
                              .copyWith(
                                  fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "\$88,740 ",
                          style:
                              Theme.of(context).textTheme.bodyLarge!.copyWith(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor,
                                  ),
                        )
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
