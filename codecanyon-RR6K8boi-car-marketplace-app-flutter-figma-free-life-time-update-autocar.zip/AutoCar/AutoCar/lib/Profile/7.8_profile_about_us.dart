// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:flutter/material.dart';

class ProfileAboutUsScreen extends StatefulWidget {
  const ProfileAboutUsScreen({super.key});

  @override
  State<ProfileAboutUsScreen> createState() => _ProfileAboutUsScreenState();
}

class _ProfileAboutUsScreenState extends State<ProfileAboutUsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 20,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s1
                        : ConstanceData.ds1,
                    height: 25,
                  ),
                ),
                Text(
                  "About Us",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            Expanded(child: SizedBox()),
            Image.asset(
              AppTheme.isLightTheme ? ConstanceData.v13 : ConstanceData.v13,
              height: 80,
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "AUTOCAR",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 18,
                  color: Theme.of(context).primaryColor,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "v 3.0.90",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                    fontSize: 12,
                    color: Theme.of(context).primaryColor,
                  ),
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "AUTOCAR is met minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                    fontSize: 14,
                  ),
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              " Velit officia consequat duis enim velit mollit. Exercitation veniam consequat",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 12, color: Theme.of(context).disabledColor),
            ),
            Expanded(child: SizedBox()),
            Text(
              "Copyright 2021 AUTOCAR | All Rights Reserved",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 12, color: Theme.of(context).disabledColor),
            ),
            SizedBox(
              height: 30,
            )
          ],
        ),
      ),
    );
  }
}
