// ignore_for_file: prefer_const_constructors, deprecated_member_use

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/Widget/textFiealds.dart';
import 'package:autocar/auth/sign_In.dart';
import 'package:autocar/auth/signup_success.dart';
import 'package:flutter/material.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s1
                        : ConstanceData.ds1,
                    height: 20,
                  ),
                )
              ],
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  SizedBox(
                    height: 40,
                  ),
                  Text(
                    "Create Account",
                    textAlign: TextAlign.start,
                    style: Theme.of(context)
                        .textTheme
                        .displayLarge!
                        .copyWith(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Sign up and get started",
                    textAlign: TextAlign.start,
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 12, color: Theme.of(context).disabledColor),
                  ),
                  SizedBox(
                    height: 40,
                  ),
                  MyTextFieald(
                      hintText: "Name",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.s7,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  MyTextFieald(
                      hintText: "Email",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.s2,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  MyTextFieald(
                      hintText: "Password",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.s3,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.s4,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 30,
                  ),
                  MyButton(
                      btnName: "Sign Up",
                      click: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SignupSuccessScreen(),
                          ),
                        );
                      }),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    children: [
                      Expanded(child: Divider()),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        "or",
                        textAlign: TextAlign.center,
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(child: Divider()),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    height: 50,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Theme.of(context).dividerColor,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          ConstanceData.ob5,
                          height: 25,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Continue with Google",
                          style: Theme.of(context)
                              .textTheme
                              .displayLarge!
                              .copyWith(
                                  fontSize: 14, fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    height: 50,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Theme.of(context).dividerColor,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          AppTheme.isLightTheme
                              ? ConstanceData.ob6
                              : ConstanceData.dob6,
                          height: 25,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Continue with Apple",
                          style: Theme.of(context)
                              .textTheme
                              .displayLarge!
                              .copyWith(
                                  fontSize: 14, fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 60,
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 40),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Don’t have an account?",
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 12, color: Theme.of(context).disabledColor),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => SignInScreen(),
                        ),
                      );
                    },
                    child: Text(
                      " Sign In",
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: Theme.of(context).primaryColor),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
