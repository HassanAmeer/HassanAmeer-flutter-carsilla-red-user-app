// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:flutter/material.dart';

class SignupSuccessScreen extends StatefulWidget {
  const SignupSuccessScreen({super.key});

  @override
  State<SignupSuccessScreen> createState() => _SignupSuccessScreenState();
}

class _SignupSuccessScreenState extends State<SignupSuccessScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 20,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s6
                        : ConstanceData.ds6,
                    height: 20,
                  ),
                )
              ],
            ),
            Expanded(child: SizedBox()),
            Image.asset(
              AppTheme.isLightTheme ? ConstanceData.s8 : ConstanceData.ds8,
              height: 120,
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Successfully Registered",
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .displayLarge!
                  .copyWith(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "Your account has been registered \nsuccesfully, now let’s enjoy Car\n features!",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 12, color: Theme.of(context).disabledColor),
            ),
            Expanded(child: SizedBox()),
            MyButton(
                btnName: "Back to Log In",
                click: () {
                  Navigator.pop(context);
                }),
            SizedBox(
              height: 30,
            )
          ],
        ),
      ),
    );
  }
}
