// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/Widget/pageview.dart';
import 'package:flutter/material.dart';

class LoginSuccessScreen extends StatefulWidget {
  const LoginSuccessScreen({super.key});

  @override
  State<LoginSuccessScreen> createState() => _LoginSuccessScreenState();
}

class _LoginSuccessScreenState extends State<LoginSuccessScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 20,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s6
                        : ConstanceData.ds6,
                    height: 20,
                  ),
                )
              ],
            ),
            Expanded(child: SizedBox()),
            Image.asset(
              AppTheme.isLightTheme ? ConstanceData.s5 : ConstanceData.ds5,
              height: 120,
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Hey! Welcome Back",
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .displayLarge!
                  .copyWith(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "Nice to see you again. Let’s find your \nfavorite car!",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.displayLarge!.copyWith(
                  fontSize: 12, color: Theme.of(context).disabledColor),
            ),
            Expanded(child: SizedBox()),
            MyButton(
                btnName: "Go to Home",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PageScreen(),
                    ),
                  );
                }),
            SizedBox(
              height: 30,
            )
          ],
        ),
      ),
    );
  }
}
