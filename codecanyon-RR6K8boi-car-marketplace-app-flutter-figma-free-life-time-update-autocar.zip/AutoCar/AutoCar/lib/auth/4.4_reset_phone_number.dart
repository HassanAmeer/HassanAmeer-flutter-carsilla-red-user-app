// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/Widget/textFiealds.dart';
import 'package:autocar/auth/4.5_verification_code.dart';
import 'package:flutter/material.dart';

class ResetPhoneNumberScreen extends StatefulWidget {
  const ResetPhoneNumberScreen({super.key});

  @override
  State<ResetPhoneNumberScreen> createState() => _ResetPhoneNumberScreenState();
}

class _ResetPhoneNumberScreenState extends State<ResetPhoneNumberScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 20,
            right: 16,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: MediaQuery.of(context).padding.bottom),
        child: Column(
          children: [
            Row(
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s1
                        : ConstanceData.ds1,
                    height: 20,
                  ),
                )
              ],
            ),
            SizedBox(
              height: 40,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Text(
                    "Reset Phone number",
                    textAlign: TextAlign.start,
                    style: Theme.of(context)
                        .textTheme
                        .displayLarge!
                        .copyWith(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Enter your email, we will send you the \nconfirmation code",
                    textAlign: TextAlign.start,
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 12, color: Theme.of(context).disabledColor),
                  ),
                  SizedBox(
                    height: 40,
                  ),
                  MyTextFieald(
                      hintText: "Phone number",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.s12,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
            MyButton(
                btnName: "Send Code Number",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => VerificationCodeScreen(),
                    ),
                  );
                }),
            SizedBox(
              height: 30,
            )
          ],
        ),
      ),
    );
  }
}
