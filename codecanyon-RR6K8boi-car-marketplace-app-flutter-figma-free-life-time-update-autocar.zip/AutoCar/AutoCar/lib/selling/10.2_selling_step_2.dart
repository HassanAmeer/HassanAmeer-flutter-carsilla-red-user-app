// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/selling/10.3_selling_step_3.dart';
import 'package:flutter/material.dart';

class SellimngStep2Screen extends StatefulWidget {
  const SellimngStep2Screen({super.key});

  @override
  State<SellimngStep2Screen> createState() => _SellimngStep2ScreenState();
}

class _SellimngStep2ScreenState extends State<SellimngStep2Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 20,
            bottom: MediaQuery.of(context).padding.bottom + 16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s1
                        : ConstanceData.ds1,
                    height: 22,
                  ),
                ),
                Text(
                  "Upload Documents",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            SizedBox(
              height: 40,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    // border: Border.all(
                    //   color: Theme.of(context).dividerColor,
                    // ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                      child: Image.asset(
                    ConstanceData.c12,
                    height: 15,
                  )),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).primaryColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "2",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).dividerColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Theme.of(context).dividerColor,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "3",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Theme.of(context).disabledColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).dividerColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Theme.of(context).dividerColor,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "4",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Theme.of(context).disabledColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).dividerColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Theme.of(context).dividerColor,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "5",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Theme.of(context).disabledColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 40,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Text(
                    "ID Card",
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 14, color: Theme.of(context).disabledColor),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Stack(
                    alignment: Alignment.topLeft,
                    children: [
                      Image.asset(
                        ConstanceData.c1,
                        fit: BoxFit.fill,
                        width: MediaQuery.of(context).size.width,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(18),
                        child: Row(
                          children: [
                            Image.asset(
                              ConstanceData.c3,
                              height: 40,
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "ID Card",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  ".pdf 300KB",
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayLarge!
                                      .copyWith(
                                          fontSize: 12,
                                          color:
                                              Theme.of(context).disabledColor),
                                ),
                              ],
                            ),
                            Spacer(),
                            Image.asset(
                              ConstanceData.c4,
                              height: 22,
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Text(
                    "Certificate of Ownership",
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 14, color: Theme.of(context).disabledColor),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Image.asset(
                        ConstanceData.c2,
                        fit: BoxFit.fill,
                        width: MediaQuery.of(context).size.width,
                      ),
                      Column(
                        children: [
                          Image.asset(
                            ConstanceData.c5,
                            height: 30,
                          ),
                          SizedBox(
                            height: 8,
                          ),
                          Text(
                            "Format DOC, PDF, JPG",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12,
                                    color: Theme.of(context).disabledColor),
                          ),
                          SizedBox(
                            height: 8,
                          ),
                          Text(
                            "Browse files",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor),
                          ),
                        ],
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Text(
                    "Vehicle License",
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 14, color: Theme.of(context).disabledColor),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Image.asset(
                        ConstanceData.c2,
                        fit: BoxFit.fill,
                        width: MediaQuery.of(context).size.width,
                      ),
                      Column(
                        children: [
                          Image.asset(
                            ConstanceData.c5,
                            height: 30,
                          ),
                          SizedBox(
                            height: 8,
                          ),
                          Text(
                            "Format DOC, PDF, JPG",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12,
                                    color: Theme.of(context).disabledColor),
                          ),
                          SizedBox(
                            height: 8,
                          ),
                          Text(
                            "Browse files",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor),
                          ),
                        ],
                      )
                    ],
                  )
                ],
              ),
            ),
            MyButton(
                btnName: "Continue",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SellingStep3Screen(),
                    ),
                  );
                })
          ],
        ),
      ),
    );
  }
}
