// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/Widget/textFiealds.dart';
import 'package:autocar/selling/10.2_selling_step_2.dart';
import 'package:flutter/material.dart';

class SellingStep1Screen extends StatefulWidget {
  const SellingStep1Screen({super.key});

  @override
  State<SellingStep1Screen> createState() => _SellingStep1ScreenState();
}

class _SellingStep1ScreenState extends State<SellingStep1Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 20,
            bottom: MediaQuery.of(context).padding.bottom + 16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s6
                        : ConstanceData.ds6,
                    height: 22,
                  ),
                ),
                Text(
                  "General Information",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            SizedBox(
              height: 40,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    // border: Border.all(
                    //   color: Theme.of(context).dividerColor,
                    // ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "1",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).dividerColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Theme.of(context).dividerColor,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "2",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Theme.of(context).disabledColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).dividerColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Theme.of(context).dividerColor,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "3",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Theme.of(context).disabledColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).dividerColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Theme.of(context).dividerColor,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "4",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Theme.of(context).disabledColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).dividerColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Theme.of(context).dividerColor,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "5",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Theme.of(context).disabledColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 40,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  MyTextFieald(
                      hintText: "Category",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v45,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          AppTheme.isLightTheme
                              ? ConstanceData.h1
                              : ConstanceData.dh1,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  MyTextFieald(
                      hintText: "Brand",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v50,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          AppTheme.isLightTheme
                              ? ConstanceData.h1
                              : ConstanceData.dh1,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  MyTextFieald(
                      hintText: "Production Year",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v51,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          AppTheme.isLightTheme
                              ? ConstanceData.h1
                              : ConstanceData.dh1,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  MyTextFieald(
                      hintText: "Car Model",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v52,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          AppTheme.isLightTheme
                              ? ConstanceData.h1
                              : ConstanceData.dh1,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  MyTextFieald(
                      hintText: "Car Paint Color",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v53,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          AppTheme.isLightTheme
                              ? ConstanceData.h1
                              : ConstanceData.dh1,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                  SizedBox(
                    height: 20,
                  ),
                  MyTextFieald(
                      hintText: "Vehicle Plate",
                      prefixIcon: IconButton(
                        icon: Image.asset(
                          ConstanceData.v54,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      suffixIcon: IconButton(
                        icon: Image.asset(
                          AppTheme.isLightTheme
                              ? ConstanceData.h1
                              : ConstanceData.dh1,
                          height: 20,
                        ),
                        onPressed: () {},
                      ),
                      click: () {}),
                ],
              ),
            ),
            MyButton(
                btnName: "Continue",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SellimngStep2Screen(),
                    ),
                  );
                })
          ],
        ),
      ),
    );
  }
}
