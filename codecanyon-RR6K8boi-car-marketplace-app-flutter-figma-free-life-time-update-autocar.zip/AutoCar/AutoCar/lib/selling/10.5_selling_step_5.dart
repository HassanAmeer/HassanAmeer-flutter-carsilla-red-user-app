// ignore_for_file: prefer_const_constructors

import 'package:autocar/Constance/constance.dart';
import 'package:autocar/Constance/theme.dart';
import 'package:autocar/Widget/buttons.dart';
import 'package:autocar/selling/10.6_selling_success_state.dart';
import 'package:flutter/material.dart';

class SellingStep5Screen extends StatefulWidget {
  const SellingStep5Screen({super.key});

  @override
  State<SellingStep5Screen> createState() => _SellingStep5ScreenState();
}

class _SellingStep5ScreenState extends State<SellingStep5Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: MediaQuery.of(context).padding.top + 20,
            bottom: MediaQuery.of(context).padding.bottom + 16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    AppTheme.isLightTheme
                        ? ConstanceData.s1
                        : ConstanceData.ds1,
                    height: 22,
                  ),
                ),
                Text(
                  "Set Location and Price",
                  style: Theme.of(context)
                      .textTheme
                      .displayLarge!
                      .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
            SizedBox(
              height: 40,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    // border: Border.all(
                    //   color: Theme.of(context).dividerColor,
                    // ),
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                      child: Image.asset(
                    ConstanceData.c12,
                    height: 15,
                  )),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).primaryColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                      child: Image.asset(
                    ConstanceData.c12,
                    height: 15,
                  )),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).primaryColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                      child: Image.asset(
                    ConstanceData.c12,
                    height: 15,
                  )),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).primaryColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Image.asset(
                      ConstanceData.c12,
                      height: 15,
                    ),
                  ),
                ),
                Container(
                  height: 1,
                  width: 40,
                  color: Theme.of(context).primaryColor,
                ),
                Container(
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                  ),
                  child: Center(
                    child: Text(
                      "5",
                      style: Theme.of(context).textTheme.displayLarge!.copyWith(
                          fontSize: 12,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 40,
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Row(
                    children: [
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                          color: AppTheme.isLightTheme
                              ? HexColor("#EFF4FF")
                              : HexColor("#1E293B"),
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                              AppTheme.isLightTheme
                                  ? ConstanceData.v10
                                  : ConstanceData.dv10,
                              height: 30,
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Tesla Model S",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            "Secondhand",
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge!
                                .copyWith(
                                    fontSize: 12,
                                    color: Theme.of(context).disabledColor),
                          )
                        ],
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: Image.asset(ConstanceData.c6),
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      Expanded(
                        child: Image.asset(ConstanceData.c7),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    "Car Detail",
                    style: Theme.of(context)
                        .textTheme
                        .displayLarge!
                        .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Category",
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                      Text(
                        "Used",
                        style:
                            Theme.of(context).textTheme.displayLarge!.copyWith(
                                  fontSize: 14,
                                ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Brand",
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                      Text(
                        "Tesla",
                        style:
                            Theme.of(context).textTheme.displayLarge!.copyWith(
                                  fontSize: 14,
                                ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Production Year",
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                      Text(
                        "2019",
                        style:
                            Theme.of(context).textTheme.displayLarge!.copyWith(
                                  fontSize: 14,
                                ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Car Model",
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                      Text(
                        "Model S",
                        style:
                            Theme.of(context).textTheme.displayLarge!.copyWith(
                                  fontSize: 14,
                                ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Car Paint Color",
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                      Text(
                        "Pearl White Multi-Coat",
                        style:
                            Theme.of(context).textTheme.displayLarge!.copyWith(
                                  fontSize: 14,
                                ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Vehicle Plate",
                        style: Theme.of(context)
                            .textTheme
                            .displayLarge!
                            .copyWith(
                                fontSize: 12,
                                color: Theme.of(context).disabledColor),
                      ),
                      Text(
                        "IA 2819 33B",
                        style:
                            Theme.of(context).textTheme.displayLarge!.copyWith(
                                  fontSize: 14,
                                ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Divider(),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    "Document Details",
                    style: Theme.of(context).textTheme.displayLarge!.copyWith(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).disabledColor),
                  ),
                ],
              ),
            ),
            MyButton(
                btnName: "Upload",
                click: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SellingSuccessStateScreen(),
                    ),
                  );
                })
          ],
        ),
      ),
    );
  }
}
